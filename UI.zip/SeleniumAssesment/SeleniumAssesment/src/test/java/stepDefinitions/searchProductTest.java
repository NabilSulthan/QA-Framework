package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.HomePage;
import pageObjects.ProductPage;

public class searchProductTest {
	private final WebDriver driver= Hooks.driver;
	public HomePage home;
	public ProductPage product;

	@Given("User already open the website mydesignation")
	public void user_already_open_the_website_mydesignation() {
		assertEquals(driver.getCurrentUrl(), "https://www.mydesignation.com/");
	}

	@When("User click on search icon")
	public void user_click_on_search_icon() {
		home=new HomePage(driver);
		home.clickSearchIcon();
	}

	@When("User input {string} name in searchbar")
	public void user_input_name_in_searchbar(String string) {
		home=new HomePage(driver);
		home.enterProductToSearch(string);
	}

	@Then("User verify specified product is shown")
	public void user_verify_specified_product_is_shown() {
		product=new ProductPage(driver);
		assertEquals(product.validSearchResult(), "1 RESULT FOUND FOR “WOMEN VINTAGE SHIRT”");
	}

	@Then("User verify no such product message is shown")
	public void user_verify_no_such_product_message_is_shown() {
		product=new ProductPage(driver);
		assertEquals(product.InvalidsearchResult(), "No results found");
	}
}



