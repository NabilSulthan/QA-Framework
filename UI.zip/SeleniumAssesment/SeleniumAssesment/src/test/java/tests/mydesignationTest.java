package tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.DriverSetup;
import base.ReusableMethods;
import pageObjects.HomePage;
import pageObjects.ProductPage;
import utilities.ExcelHandling;
import utilities.ExtentReportsListener;

//Listener for generating Extent Reports for test execution tracking
@Listeners(utilities.ExtentReportsListener.class)
public class mydesignationTest {

	public static WebDriver driver;
	public static ReusableMethods re;
	public static HomePage home;
	public static ProductPage product;


	@BeforeMethod(groups= {"view","add"})
	public void before() throws InterruptedException
	{
		driver= DriverSetup.invokeEgde(); //invoke edge browser
		re= new ReusableMethods(driver);
		re.openWebsite();   //open mydesignation website
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ExtentReportsListener.setDriver(driver);
	}


	//test to view product based on search 
	@Test(priority=1,groups="view")
	public void viewProduct() 
	{
		home=new HomePage(driver);  //object creation for homepage
		product = new ProductPage(driver);  //object for productpage

		home.searchProduct(" Dragon Men's Shirt"); //search product by clicking on search icon and enter product to search in search bar
		product.viewProduct(); // view the product shown in search results

		assertEquals(product.verifyProductName(), "Men Shirt"); //verify viewed product name			

	}


	// DataProvider for test data   // fetching data from excel file
	@DataProvider(name="productToSearch")
	public String[][] getLoginData() throws IOException {
		String path = System.getProperty("user.dir")+"\\exceldata\\product.xlsx";
		String sheet = "Sheet1";
		return ExcelHandling.fetchUserDetails(path, sheet); // Fetch data from Excel sheet
	}


	//test to add product to cart
	@Test(dataProvider = "productToSearch",priority=2,groups="add")
	public void addProductToCart(String productName) {
		home=new HomePage(driver);  
		product = new ProductPage(driver); 			
		home.searchProduct(productName); //providing product to search using dataprovider
		product.viewProduct(); 

		product.addProductToCart(); //add product to cart 			
		assertEquals(product.numInCartIcon(),"1 item");  //verify if 1 item is added to cart

	}	


	// Method to capture a screenshot of failed test cases
	@AfterMethod(groups= {"add","search"})
	public void captureScreenshotOfFail(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				Date d1 = new Date();
				FileUtils.copyFile(screenshot, new File("FailedScreenshots/" + d1.getTime() + "ss.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}


}
