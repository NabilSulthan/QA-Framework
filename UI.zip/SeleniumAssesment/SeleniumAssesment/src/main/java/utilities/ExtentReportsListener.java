package utilities;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import utilities.ExtentManager;

public class ExtentReportsListener implements ITestListener {
	static WebDriver driver;
	public ExtentReports extent;
	public ExtentTest test;
	public ExtentReportsListener() {
	}
	public static void setDriver(WebDriver driver) {
		ExtentReportsListener.driver = driver;
	}
	public void onStart(ITestContext context) {
		try {
			extent = ExtentManager.createInstance();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void onTestStart(ITestResult result) {
		test = extent.createTest(result.getName());
	}
	public void onTestSuccess(ITestResult result) {
		test.log(Status.PASS, "Test case passed");
		test.log(Status.PASS, MarkupHelper.createLabel(result.getName(), ExtentColor.GREEN));
		String screenshotPath = takeScreenshot(result.getName());
		if (screenshotPath != null) {
			test.addScreenCaptureFromPath(screenshotPath);
		}
	}
	public void onTestFailure(ITestResult result) {
		test.log(Status.FAIL, "Test case Failed");
		test.log(Status.FAIL, result.getThrowable());
		test.log(Status.FAIL, MarkupHelper.createLabel(result.getName(), ExtentColor.RED));
		String screenshotPath = takeScreenshot(result.getName());
		if (screenshotPath != null) {
			test.addScreenCaptureFromPath(screenshotPath);
		}
	}
	public void onTestSkipped(ITestResult result) {
		test.log(Status.SKIP, "Test case skipped");
		test.log(Status.SKIP, MarkupHelper.createLabel(result.getName(), ExtentColor.ORANGE));
		String screenshotPath = takeScreenshot(result.getName());
		if (screenshotPath != null) {
			test.addScreenCaptureFromPath(screenshotPath);
		}
	}
	public void onFinish(ITestContext context) {
		extent.flush();
	}
	public static String takeScreenshot(String testName) {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = System.getProperty("user.dir") + "/Screenshots/" + testName + dateName + ".png";
		File finalDestination = new File(destination);
		try {
			FileUtils.copyFile(source, finalDestination);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		return destination;
	}
}