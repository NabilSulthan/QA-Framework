package com.ust.karate;

import com.intuit.karate.junit5.Karate;

public class JUnitRunner {
	@Karate.Test
	Karate karateTest() {
		return Karate.run("classpath:karate.feature").relativeTo(getClass());
	}
}































































//@Karate.Test
//Karate karateTest() {
//	return Karate.run("classpath:karate.feature").relativeTo(getClass());
//}