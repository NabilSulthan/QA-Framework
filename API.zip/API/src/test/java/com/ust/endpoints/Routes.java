package com.ust.endpoints;

public class Routes {

	public static String baseuri="https://freefakeapi.io/api";
	public static String post_basePath="/posts";
	public static String get_basePath="/posts";
	public static String getById_basePath="/posts/{uid}";
	public static String delete_basePath="/posts/{uid}";
	public static String update_basePath="/posts/{uid}";
	
}
