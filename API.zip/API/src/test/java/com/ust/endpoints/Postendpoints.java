package com.ust.endpoints;

import com.ust.payloads.Post;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Postendpoints {

	public static Response addPost(Post payload) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given().headers("Content-Type", ContentType.JSON, "Accept", ContentType.JSON)
				.baseUri(Routes.baseuri).basePath(Routes.post_basePath).contentType("application/json")
				.accept(ContentType.JSON).body(payload).when().post();
		return response;
	}

	public static Response getPost() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given().headers("Content-Type", ContentType.JSON, "Accept", ContentType.JSON)
				.baseUri(Routes.baseuri).basePath(Routes.get_basePath).contentType("application/json")
				.accept(ContentType.JSON).when().get();
		return response;
	}

	public static Response deletePost(int id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given().headers("Content-Type", ContentType.JSON, "Accept", ContentType.JSON)
				.baseUri(Routes.baseuri).basePath(Routes.delete_basePath).pathParam("uid", id)
				.contentType("application/json").accept(ContentType.JSON).when().delete();
		return response;
	}

	public static Response updatePost(int id, Post payload) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given().headers("Content-Type", ContentType.JSON, "Accept", ContentType.JSON)
				.baseUri(Routes.baseuri).basePath(Routes.update_basePath).pathParam("uid", id)
				.contentType("application/json").accept(ContentType.JSON).body(payload).when().patch();
		return response;
	}

	public static Response getPostById(int id) {
		RestAssured.useRelaxedHTTPSValidation();  
		Response response = RestAssured.given().headers("Content-Type", ContentType.JSON, "Accept", ContentType.JSON)
				.baseUri(Routes.baseuri).basePath(Routes.getById_basePath).pathParam("uid", id)
				.contentType("application/json").accept(ContentType.JSON).when().get();
		return response;
	}

}






