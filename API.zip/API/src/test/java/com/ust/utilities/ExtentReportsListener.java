package com.ust.utilities;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;


public class ExtentReportsListener implements ITestListener {
	static WebDriver driver;
	
	// ExtentReports and ExtentTest objects
    public ExtentReports extent;
    public ExtentTest test;
    String filepath;
   

    // Method executed at the start of the test suite
    public void onStart(ITestContext context) {
        try {
            extent = ExtentManager.createInstance();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method executed before each test case starts
    public void onTestStart(ITestResult result) {
        test = extent.createTest(result.getName());
    }

    // Method executed after a test case passes
    public void onTestSuccess(ITestResult result) {
        // Log test case as PASSED
        test.log(Status.PASS, "Test case PASSED");
        test.log(Status.PASS, MarkupHelper.createLabel(result.getName(), ExtentColor.GREEN));

       
    }

    // Method executed after a test case fails
    public void onTestFailure(ITestResult result) {
        // Log test case as FAILED
        test.log(Status.FAIL, "Test case FAILED");
        test.log(Status.FAIL, MarkupHelper.createLabel(result.getName(), ExtentColor.RED));

       
        
    }

    // Method executed after a test case is skipped
    public void onTestSkipped(ITestResult result) {
        test.log(Status.SKIP, "Test case SKIPPED");
        test.log(Status.SKIP, MarkupHelper.createLabel(result.getName(), ExtentColor.AMBER));
    }

    // Method executed after the entire test suite finishes
    public void onFinish(ITestContext context) {
        extent.flush();
    }

   
}