package com.ust.utilities;

import java.io.IOException;

import org.testng.annotations.DataProvider;

public class DataProviders {

	@DataProvider(name = "data")
	public String[][] getItems() throws IOException {
		
		return ExcelData.getExcelData(System.getProperty("user.dir")+"//src//test//resources//postData.xlsx", "Sheet1");
	}
	
}
