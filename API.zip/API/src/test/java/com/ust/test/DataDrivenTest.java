package com.ust.test;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.endpoints.Postendpoints;
import com.ust.payloads.Post;
import com.ust.utilities.DataProviders;
import com.ust.utilities.ExtentReportsListener;

import io.restassured.response.Response;
@Listeners(ExtentReportsListener.class)
public class DataDrivenTest {
	@Test(priority = 1, dataProvider = "data", dataProviderClass = DataProviders.class)
    public void testPostUser(String title, String content, String slug, String picture, String users) {
        Post payload = new Post();
        int user=Integer.parseInt(users);
        payload.setContent(content);
        payload.setPicture(picture);
        payload.setSlug(slug);
        payload.setTitle(title);
        payload.setUser(user);
        
        
        // Assuming UserEndPoints.createUser() method returns a Response object
        Response response = Postendpoints.addPost(payload);
        
        response.then().log().all();
        Assert.assertEquals(response.getStatusCode(), 201);
    }

		
	
	
	
	
}















































