package com.ust.test;

import java.io.File;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.ust.endpoints.Postendpoints;
import com.ust.payloads.Post;
import com.ust.utilities.ExtentReportsListener;

import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;

@Listeners(ExtentReportsListener.class)
public class PostTests {
	
    private Faker faker;
    private Post payload;

    @BeforeClass
    public void setup() {
        faker = new Faker();
        payload = new Post();
        
        
       payload.setTitle(faker.funnyName().name());
       payload.setContent(faker.name().name());
       payload.setPicture("https://path.to/picture.jpg");
       payload.setSlug(faker.name().prefix());
       payload.setUser(faker.number().numberBetween(1, 11));
        
       
    }
    @Test(priority = 1)
    public void testaddPost()
    {
        Response response = Postendpoints.addPost(payload);
        response.then().log().all();
        Assert.assertEquals(response.getStatusCode(),201);
    }
    @Test(priority=2)
    public void testGetPosts()
    {
        Response response = Postendpoints.getPost();
       response.then().log().all();
       Assert.assertEquals(response.getStatusCode(),200);
    }
    @Test(priority = 3)
    public void testUpdatePost()
    {
    		 faker = new Faker();
 	        payload = new Post();
 	        
 	      
    	        
    	        // Update data using payload
 	            int updatedId=7;
    	        String updatedTitle = "This is the title";
    	        String updateContent ="This is the post content";
    	        String updatePicture ="https://path.to/picture.jpg";
    	       
    	        
    	        
    	        payload.setTitle(updatedTitle);
    	        payload.setContent(updateContent);
    	        payload.setPicture(updatePicture);
    	        
    	        // Update user using UserEndPoints.updateUser()
    	        Response response = Postendpoints.updatePost(updatedId, payload);
    	        response.then().log().all();
    	        Assert.assertEquals(response.getStatusCode(), 200);

    	        // Checking data after updation
    	        Response responseAfterUpdate = Postendpoints.getPostById(updatedId);
    	        responseAfterUpdate.then().log().all();
    	        Assert.assertEquals(responseAfterUpdate.getStatusCode(), 200);
//
//    	        // Validate the updated data
//    	        Products updatedProducts = responseAfterUpdate.getBody().as(Products.class);
//    	        Assert.assertEquals(updatedProducts.getName(), updatedName);
//    	        Assert.assertEquals(updatedProducts.getPrice(), updatedPrice);
//    	        Assert.assertEquals(updatedProducts.getDesc(), updatedDesc);
    
    }
    @Test(priority = 4)
    public void testDeletePostById()
    {
        Response response = Postendpoints.deletePost(11);
        response.then().log().all();
        Assert.assertEquals(response.getStatusCode(),204);
    }
    @Test(priority = 5)
    public void schemavalidation() {
    	
    	String schemaFile=System.getProperty("user.dir") + "\\src\\test\\resources\\schema.json";
    	Response response=Postendpoints.getPostById(3);
    	response.then().log().all()
    	.assertThat()
    	.body(JsonSchemaValidator.matchesJsonSchema(new File(schemaFile)));
    }
}

























































