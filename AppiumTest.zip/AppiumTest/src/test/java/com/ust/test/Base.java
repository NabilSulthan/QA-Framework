package com.ust.test;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.By;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.utilities.AndroidActions;
import com.ust.utilities.ExtentReportsListener;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

@Listeners(ExtentReportsListener.class)
public class Base {
	public AndroidDriver driver;
	AndroidActions functions;
	@Test()
	public void ConfigureAppium() throws IOException, InterruptedException {

		// Load properties
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(
				System.getProperty("user.dir") + "\\src\\main\\resources\\config.properties");
		prop.load(fis);
		// Configure Appium options and initialize driver
		String ipAddress = prop.getProperty("ipAddress");
		String port = prop.getProperty("port");
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName(prop.getProperty("AndroidDeviceName"));
		if (Boolean.parseBoolean(prop.getProperty("appUsingPath"))) {
			options.setApp(System.getProperty("user.dir") + prop.getProperty("appPath"));
		} else {
			options.setAppPackage(prop.getProperty("appPackage"));
			options.setAppActivity(prop.getProperty("appActivity"));
		}
		driver = new AndroidDriver(new URL("http://" + ipAddress + ":" + port), options);
		functions = new AndroidActions(driver);
		
//		System.out.println(hashMap.get("number1"));
	   
	     driver.findElement(By.id("com.google.android.calculator:id/formula"));
	     
	     
	   
	}
	
	
}

