package com.ust.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class FileReaders {

	
	//To read data from Json file
	   public static List<HashMap<String,String>> getJSon(String filePath) throws IOException{
			
			String jsonString = FileUtils.readFileToString(new File(filePath), StandardCharsets.UTF_8);
			ObjectMapper mapper=new ObjectMapper();
			List<HashMap<String,String>> list=mapper.readValue(jsonString,
					new TypeReference<List<HashMap<String,String>>>() {
			});
			
			return list;
			
		}
	   
	 //To read data from Excel file
	   public static String[][] excelHandling(String path, String sheetName) throws IOException {
			FileInputStream fis = new FileInputStream(path);
			Workbook workbook = new XSSFWorkbook(fis);
			Sheet sheet = workbook.getSheet(sheetName);
			int rowCount = sheet.getPhysicalNumberOfRows(); // to get used row count
			Row row = sheet.getRow(0);
			int colCount = row.getPhysicalNumberOfCells();// to get used cell count
			String[][] data=new String [rowCount][colCount];
			DataFormatter df=new DataFormatter();
			for (int i = 0; i < rowCount; i++) {
				for(int j=0;j<colCount;j++) {
				data[i][j] = df.formatCellValue(sheet.getRow(i).getCell(j));
				}
			}
			for (int i = 0; i < rowCount; i++) {
				for(int j=0;j<colCount;j++) {
				//System.out.println(data[i][j]);
				}
			}
			
		return data;
	}
	
}
