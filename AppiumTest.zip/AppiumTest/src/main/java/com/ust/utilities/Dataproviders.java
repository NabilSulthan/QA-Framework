package com.ust.utilities;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;
import com.ust.utilities.FileReaders;

public class Dataproviders {

	
	@DataProvider(name="jsondata")
	public static Object[] getJsonData() throws IOException{
		
		List<HashMap<String, String>> map = FileReaders.getJSon(System.getProperty("user.dir")+"//src/test//resources//testdata");
		
		return map.toArray();
		
	}
	
	@DataProvider(name="jsondata")
	public static String[][] getExcelData() throws IOException{
		
		return FileReaders.excelHandling(System.getProperty("user.dir")+"//src/test//resources//testdata","Sheet1");
		
		
		
	}
	
}
