package com.ust.utilities;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {
	public static ExtentReports extent;
	public static ExtentSparkReporter htmlReporter;
	
	public static ExtentReports createInstance() throws IOException {
		//for naming
		String repname="TestReport-"+ getTimeStamp()+".html";
		//for locating report
		htmlReporter=new ExtentSparkReporter(System.getProperty("user.dir")+"//reports//"+repname);
		//configuration of report
		htmlReporter.config().setDocumentTitle("Appium Framework");
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setReportName("calculator");
		
		extent=new ExtentReports();
		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("OS", "Windows");
		extent.setSystemInfo("Host Name", "LocalHost");
		extent.setSystemInfo("Environment", "QA");
		return extent;
	}
	
	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}
}
